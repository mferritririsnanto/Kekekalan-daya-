// Audit otomatis: jalankan dengan  node tests/audit-test.js
const fs=require('fs'),vm=require('vm'),path=require('path');
const dir=path.join(__dirname,'..'),html=fs.readFileSync(dir+'/index.html','utf8'),src=fs.readFileSync(dir+'/script.js','utf8');
const EL={},REC={};let RAF=null;
const gen=new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?undefined:k==='valueOf'?()=>0:k==='toString'?()=>'':gen,apply:()=>gen,set:()=>true});
const ctx=id=>new Proxy({},{get:(t,k)=>k==='clearRect'?()=>{REC[id]=[]}:k==='moveTo'||k==='lineTo'?(x,y)=>(REC[id]=REC[id]||[]).push([x,y]):k==='measureText'?()=>({width:50}):()=>{},set:()=>true});
const el=id=>EL[id]||(EL[id]=new Proxy({clientWidth:400,value:''},{get:(t,k)=>k in t?t[k]:k==='getContext'?()=>ctx(id):k==='valueOf'?()=>0:k==='toString'?()=>'':k===Symbol.toPrimitive?undefined:gen,set:(t,k,v)=>(t[k]=v,true)}));
const sb={document:{getElementById:el},matchMedia:()=>({matches:false}),devicePixelRatio:1,addEventListener(){},requestAnimationFrame:cb=>{RAF=cb},console};
vm.createContext(sb);vm.runInContext(src,sb);
const T=c=>vm.runInContext(c,sb),rows=[];
const chS=(n,e,g,S,tol)=>{const err=Math.abs(g-e)/S;rows.push([n,e,g,tol,err<=tol?'LULUS':'GAGAL'])};
const chk=(n,e,g,tol,rel=true)=>{const err=rel?Math.abs(g-e)/Math.max(Math.abs(e),1e-12):Math.abs(g-e);rows.push([n,e,g,tol,err<=tol?'LULUS':'GAGAL'])};
const ok=(n,c,i='')=>rows.push([n,'',i,'',c?'LULUS':'GAGAL']);
const set=(m,o)=>T(`mode=${JSON.stringify(m)};Object.assign(P,${JSON.stringify(o)});sync();update();0`);
// referensi independen (fasor kompleks)
function ref(m,p){const w=2*Math.PI*p.f,xl=m.includes('L')?w*p.L/1e3:0,xc=m.includes('C')?1/(w*p.C*1e-6):0,r=m.includes('R')?p.R:0,x=xl-xc,Z=Math.hypot(r,x),I=p.V/Z;
 // Ifasor = V/(r+jx); S=V*conj(I) = V^2/(r-jx)... => P=V^2 r/Z^2, Q=V^2 x/Z^2
 return{Z,I,P:p.V*p.V*r/Z/Z,Q:p.V*p.V*x/Z/Z,S:p.V*I,PF:r/Z,th:Math.atan2(x,r),XL:xl,XC:xc}}
const cases=[["RLC",{V:100,f:50,R:20,L:100,C:100}],["RL",{V:120,f:60,R:10,L:500,C:100}],["RC",{V:12,f:400,R:47,L:100,C:22}],["R",{V:230,f:50,R:100,L:100,C:100}],["L",{V:50,f:50,R:20,L:200,C:100}],["C",{V:50,f:50,R:20,L:100,C:220}],["RLC",{V:100,f:1000,R:5,L:10000,C:1}]];
cases.forEach(([m,p],ci)=>{set(m,p);const r=ref(m,p),M=T('M'),S=T('ST'),tag=`K${ci+1} ${m} `;
 chk(tag+'|Z|',r.Z,M.Z,1e-9);chk(tag+'Irms',r.I,M.I,1e-9);chS(tag+'P (galat/S)',r.P,M.Pw,r.S,1e-9);chS(tag+'Q (galat/S)',r.Q,M.Q,r.S,1e-9);chk(tag+'S',r.S,M.S,1e-9);chk(tag+'PF',r.PF,M.PF,1e-9,false);
 chk(tag+'theta',r.th,M.th,1e-9,false);chk(tag+'S²=P²+Q²',M.S,Math.hypot(M.Pw,M.Q),1e-9);
 chS(tag+'rata2 pR(num) vs P (galat/S)',r.P,S.pR,r.S,1e-9);chS(tag+'rata2 pS(num) vs P (galat/S)',r.P,S.pS,r.S,1e-9);
 chk(tag+'|rata2 pL|/S',0,Math.abs(S.pL)/r.S,1e-9,false);chk(tag+'|rata2 pC|/S',0,Math.abs(S.pC)/r.S,1e-9,false);chk(tag+'residual maks/S',0,S.res/r.S,1e-9,false)});
// energi: dW/dt = p
set("RLC",{V:100,f:50,R:20,L:100,C:100});let e1=0,e2=0,mp=0;const per=0.02,dt=per/1e5;
for(let k=0;k<400;k++){const t=per*k/400,a=T(`sig(${t+dt})`),b=T(`sig(${t-dt})`),c=T(`sig(${t})`);e1=Math.max(e1,Math.abs((a.WL-b.WL)/(2*dt)-c.pL));e2=Math.max(e2,Math.abs((a.WC-b.WC)/(2*dt)-c.pC));mp=Math.max(mp,Math.abs(c.pL),Math.abs(c.pC))}
chk('dWL/dt = pL (galat/maks)',0,e1/mp,1e-6,false);chk('dWC/dt = pC (galat/maks)',0,e2/mp,1e-6,false);
// fase
[['L',1],['C',-1]].forEach(([m,s])=>{set(m,{V:100,f:50,R:20,L:100,C:100});let mi=0,iv=-1,tv=0,ti=0;for(let k=0;k<4000;k++){const t=.02*k/4000,g=T(`sig(${t})`);if(g.i>iv){iv=g.i;ti=t}}
 const lag=(ti-0.005+.02)%.02/.02*360;chk(`fase ${m}: i vs v (derajat, +=tertinggal)`,s*90<0?270:90,lag,0.5,false)});
set("R",{V:100,f:50,R:20,L:100,C:100});chk('R murni Q',0,T('M.Q'),1e-12,false);chk('R murni PF',1,T('M.PF'),1e-12,false);
set("RLC",{V:100,f:50,R:20,L:100,C:100});T('load(PRE.res)');chk('Resonansi |XL-XC|/XL',0,Math.abs(T('M.XL-M.XC'))/T('M.XL'),1e-9,false);chk('Resonansi theta',0,T('M.th'),1e-9,false);chk('Resonansi PF',1,T('M.PF'),1e-9);chk('Resonansi Q',0,T('M.Q'),1e-6,false);chk('Resonansi Irms=V/R',100/20,T('M.I'),1e-9);
// grafik: rata-rata kurva daya sumber yang DIGAMBAR = P analitik
set("RLC",{V:100,f:50,R:20,L:100,C:100});T('draw()');{const seg=[];let cur=[];for(const q of REC.c2){cur.push(q);}
 // cari segmen 201 titik: moveTo diikuti 200 lineTo berturut2
 const pts=REC.c2;let idx=-1;for(let i=0;i+200<pts.length;i++){if(pts[i][0]===8&&i>2){idx=i;break}}
 const s=pts.slice(idx,idx+201);let mx=0;const Tw=2*T('M.T');for(let k=0;k<=200;k++){const g=T(`sig(${Tw*k/200})`);mx=Math.max(mx,Math.abs(g.pS),Math.abs(g.pR),Math.abs(g.pL),Math.abs(g.pC),Math.abs(g.pT))}
 const v=s.slice(0,200).map(q=>(106-q[1])/66*mx),m=v.reduce((a,b)=>a+b)/200;chk('Rata-rata kurva c2 (digambar) vs P analitik',T('M.Pw'),m,1e-3)}
const h1=JSON.stringify(REC.c2);set("RLC",{V:100,f:50,R:200,L:100,C:100});T('draw()');ok('Grafik c2 berubah saat R berubah',JSON.stringify(REC.c2)!==h1);
// interaktivitas
set("RLC",{V:100,f:50,R:20,L:100,C:100});
Object.entries({V:1,f:1,R:1,L:1,C:1}).forEach(([k])=>{const b=T(`P.${k}`);el('s'+k).oninput({target:{value:700}});const a=T(`P.${k}`),Iok=Math.abs(T('M.I')-T('P.V/Math.max(Math.hypot(M.Rr,M.X),1e-9)'))<1e-9;ok(`slider ${k} mengubah P & hasil`,a!==b&&Iok,`${b}→${a}`);
 el('n'+k).onchange({target:{value:'abc'}});ok(`input ${k}: teks 'abc' diabaikan`,T(`P.${k}`)===a);el('n'+k).onchange({target:{value:'1e999'}});ok(`input ${k}: Infinity diabaikan`,T(`P.${k}`)===a);
 el('n'+k).onchange({target:{value:'999999'}});const hi=T(`D.${k}[2]`);ok(`input ${k}: dijepit ke maks`,T(`P.${k}`)===hi);el('n'+k).onchange({target:{value:'-3'}});ok(`input ${k}: dijepit ke min`,T(`P.${k}`)===T(`D.${k}[1]`));
 {const[,lo,hi,lg]=T(`D.${k}`);el('n'+k).onchange({target:{value:String(lg?lo*Math.sqrt(hi/lo):(lo+hi)/2)}});ok(`input ${k}: slider tersinkron (≈500)`,Math.abs(el('s'+k).value-500)<1,String(el('s'+k).value))}});
['R','L','C','RLC','RL','RC'].forEach(m=>{el('mode').onchange({target:{value:m}});const sv=el('ckt').innerHTML;const letters=[...sv.matchAll(/>([RLC]) = /g)].map(x=>x[1]).join('');ok(`mode ${m}: diagram = ${m}`,letters===m&&(sv.match(/id="d\d+"/g)||[]).length===20&&T('mode')===m,letters)});
T('Object.assign(P,DEF);mode="RLC";sync();update()');
const exp={rmurni:q=>Math.abs(q.Q)<1e-9&&q.PF===1,ind:q=>q.Q>0,kap:q=>q.Q<0,res:q=>Math.abs(q.th)<1e-6&&q.PF>.999999,bawah:q=>q.Q<0,atas:q=>q.Q>0,pfr:q=>q.PF<.1,pft:q=>q.PF>.99};
Object.keys(exp).forEach(k=>{el('preset').onchange({target:{value:k}});ok(`preset ${k} konsisten`,exp[k](T('M')),`PF=${T('M.PF').toPrecision(4)} Q=${T('M.Q').toPrecision(4)} f=${T('P.f').toPrecision(4)}`)});
el('reset').onclick();ok('reset: nilai awal',JSON.stringify(T('P'))===JSON.stringify(T('DEF'))&&T('mode')==='RLC');
const ph=T('phase');RAF(1000);ok('frame memajukan fase saat play',T('phase')!==ph);el('play').onclick();const p2=T('phase');RAF(3000);ok('jeda menghentikan fase',T('phase')===p2&&T('playing')===false);el('play').onclick();ok('lanjutkan',T('playing')===true);
// ekstrem
let bad=0,n=0;for(const m of ['R','L','C','RL','RC','RLC'])for(const V of [1,240])for(const f of [1,1000])for(const R of [1,1000])for(const L of [1,1e4])for(const C of [1,1e4]){n++;try{set(m,{V,f,R,L,C});T('draw()');const M=T('M'),S=T('ST');if(![...Object.values(M),...Object.values(S)].filter(x=>typeof x==='number').every(Number.isFinite)||S.res/M.S>1e-9)bad++}catch(e){bad++;console.log('ERR',m,V,f,R,L,C,e.message)}}
ok(`sudut parameter ekstrem (${n} kombinasi): semua hingga & residual<1e-9·S`,bad===0,`bermasalah=${bad}`);
// statis
const ids=[...src.matchAll(/\$\("([A-Za-z0-9]+)"\)/g)].map(x=>x[1]);const miss=[...new Set(ids)].filter(i=>!html.includes(`id="${i}"`)&&!['ckt'].includes(i));ok('semua id di script ada di HTML',miss.length===0,miss.join());
ok('tidak ada URL eksternal/CDN',!/https?:\/\//.test(html+src+fs.readFileSync(dir+'/style.css','utf8')));
ok('path aset relatif & ada',['style.css','script.js'].every(f=>html.includes(f)&&fs.existsSync(dir+'/'+f)));
ok('canvas punya label aksesibilitas',[...html.matchAll(/<canvas[^>]*>/g)].every(m=>/aria-label/.test(m[0])));
ok('slider punya aria-valuetext',/aria-valuetext/.test(src));
const fails=rows.filter(r=>r[4]==='GAGAL');console.log(`Total ${rows.length}, lulus ${rows.length-fails.length}, gagal ${fails.length}`);fails.forEach(r=>console.log('GAGAL',JSON.stringify(r)));
if(process.argv[2]==='-v')rows.filter(r=>/^K[123] .*(Irms|P \(|Q \(|PF)/.test(r[0])).forEach(r=>console.log(r.join(' | ')));

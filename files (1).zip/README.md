# Hukum Kekekalan Daya pada Rangkaian AC
Simulasi interaktif (HTML + CSS + JavaScript murni, tanpa CDN, tanpa backend) untuk daya aktif, reaktif, semu, faktor daya, resonansi, dan neraca daya sesaat pada rangkaian R, L, C, RL, RC, dan RLC seri.

## Tujuan belajar
Memahami RMS, reaktansi, impedansi, sudut fase, P/Q/S, PF, resonansi, dan perbedaan daya sesaat vs rata-rata.

## Struktur file
`index.html`, `style.css`, `script.js`, `README.md`, `LICENSE`

## Jalankan lokal
Buka `index.html` di browser (klik dua kali). Tidak perlu instalasi.

## Publikasi ke GitHub Pages
1. Buat repository baru di github.com (publik), misalnya `ac-power-conservation`.
2. Klik **Add file > Upload files**, unggah kelima file (index.html di akar repository), lalu **Commit changes**.
3. Buka **Settings > Pages**. Pada *Build and deployment* pilih **Deploy from a branch**, branch **main**, folder **/ (root)**, lalu **Save**.
4. Tunggu 1–2 menit. URL: `https://<username>.github.io/ac-power-conservation/`.
5. Uji di laptop dan HP (buka URL yang sama).

## Jika tidak terbuka
Pastikan nama file huruf kecil persis (`index.html`), file ada di akar branch yang dipilih, repository publik, dan tunggu proses deploy selesai (tab Actions). Semua path bersifat relatif.

## Model fisika dan batasan
Sumber sinusoidal ideal, komponen linear ideal, kondisi tunak. Residual neraca daya dihitung dari pS − (pR+pL+pC) dan hanya berisi galat floating-point. Rata-rata memakai 400 sampel per periode. Animasi arus hanya representasi visual. Persamaan ditampilkan sebagai teks (tanpa KaTeX).

## Pengujian otomatis
`node tests/audit-test.js` menjalankan script.js dengan DOM tiruan dan memeriksa fisika, neraca daya, kontrol, dan kasus ekstrem. Nilai Q dan θ yang lebih kecil dari 1e-9 (relatif) ditampilkan sebagai 0 untuk membuang sisa pembulatan floating-point; residual neraca daya tidak dimanipulasi.

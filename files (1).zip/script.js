"use strict";
const $=id=>document.getElementById(id),PI=Math.PI;
const fmt=(x,u="")=>Number.isFinite(x)?(Math.abs(x)<1e-3&&x!==0?x.toExponential(2):+x.toPrecision(4))+(u?" "+u:""):"—";
const D={V:["Tegangan RMS",1,240,0,"V"],f:["Frekuensi",1,1000,1,"Hz"],R:["Resistansi R",1,1000,1,"Ω"],L:["Induktansi L",1,1e4,1,"mH"],C:["Kapasitansi C",1,1e4,1,"µF"]};
const DEF={V:100,f:50,R:20,L:100,C:100};let P={...DEF},mode="RLC",playing=true,phase=0,speed=1,nper=2,last=0,M,ST,DOTS=[];
const f0of=(L,C)=>1/(2*PI*Math.sqrt(L/1e3*C/1e6));
const PRE={rmurni:{m:"R",V:100,R:50,f:50},ind:{m:"RL",R:10,L:200,f:50},kap:{m:"RC",R:10,C:200,f:50},res:{m:"RLC",R:20,L:100,C:100,k:1},bawah:{m:"RLC",R:20,L:100,C:100,k:.5},atas:{m:"RLC",R:20,L:100,C:100,k:2},pfr:{m:"RL",R:5,L:300,f:50},pft:{m:"RL",R:100,L:10,f:50}};
Object.entries(D).forEach(([k,[n,lo,hi,lg,u]])=>{$("sliders").insertAdjacentHTML("beforeend",`<div class="row" id="r${k}"><label for="n${k}">${n} (${lo}–${hi} ${u})</label><input type="range" id="s${k}" min="0" max="1000" aria-label="${n}, slider"><input type="number" id="n${k}" min="${lo}" max="${hi}" step="any"><span>${u}</span></div>`);
$("s"+k).oninput=e=>{const s=e.target.value/1000;setP(k,lg?lo*Math.pow(hi/lo,s):lo+(hi-lo)*s)};
$("n"+k).onchange=e=>setP(k,parseFloat(e.target.value))});
function setP(k,v){$("preset").value="";const[,lo,hi]=D[k];if(Number.isFinite(v))P[k]=Math.min(hi,Math.max(lo,v));sync();update()}
function sync(){$("mode").value=mode;for(const k in D){const[,lo,hi,lg]=D[k];$("n"+k).value=+P[k].toPrecision(5);$("s"+k).setAttribute("aria-valuetext",fmt(P[k],D[k][4]));$("s"+k).value=1000*(lg?Math.log(P[k]/lo)/Math.log(hi/lo):(P[k]-lo)/(hi-lo));$("r"+k).classList.toggle("off","RLC".includes(k)&&!mode.includes(k))}}
function calc(){const hR=mode.includes("R"),hL=mode.includes("L"),hC=mode.includes("C"),w=2*PI*P.f,Rr=hR?P.R:0,L=P.L/1e3,Cc=P.C/1e6,XL=hL?w*L:0,XC=hC?1/(w*Cc):0,X=XL-XC,Z=Math.max(Math.hypot(Rr,X),1e-9),th0=Math.atan2(X,Rr),th=Math.abs(th0)<1e-9?0:th0,I=P.V/Z,S=P.V*I,Q0=S*Math.sin(th0);
return M={hR,hL,hC,w,Rr,L,Cc,XL,XC,X,Z,th,I,S,Pw:S*Math.cos(th),Q:Math.abs(Q0)<1e-9*S?0:Q0,PF:Math.cos(th),f0:1/(2*PI*Math.sqrt(L*Cc)),T:1/P.f,Vp:Math.SQRT2*P.V,Ip:Math.SQRT2*I}}
function sig(t){const m=M,a=m.w*t-m.th,i=m.Ip*Math.sin(a),v=m.Vp*Math.sin(m.w*t),vR=m.Rr*i,vL=m.hL?m.Ip*m.XL*Math.cos(a):0,vC=m.hC?-m.Ip*m.XC*Math.cos(a):0,pR=vR*i,pL=vL*i,pC=vC*i,pS=v*i;
return{v,i,pS,pR,pL,pC,pT:pR+pL+pC,WL:m.hL?.5*m.L*i*i:0,WC:m.hC?.5*m.Cc*vC*vC:0}}
function stats(){const N=400;let s={pS:0,pR:0,pL:0,pC:0,res:0};for(let k=0;k<N;k++){const g=sig(M.T*k/N);s.pS+=g.pS/N;s.pR+=g.pR/N;s.pL+=g.pL/N;s.pC+=g.pC/N;s.res=Math.max(s.res,Math.abs(g.pS-g.pT))}return s}
const SY={R:x=>`M${x-34} 40h14l4-10 8 20 8-20 8 20 8-20 4 10h14`,L:x=>`M${x-34} 40h10a6 6 0 0 1 12 0 6 6 0 0 1 12 0 6 6 0 0 1 12 0 6 6 0 0 1 12 0h10`,C:x=>`M${x-34} 40h30M${x-4} 24v32M${x+4} 24v32M${x+4} 40h30`};
function pos(s){s=((s%1040)+1040)%1040;return s<420?[40+s,40]:s<520?[460,40+s-420]:s<940?[460-(s-520),140]:[40,140-(s-940)]}
function build(){const cs=[...mode],n=cs.length;let h='<path d="M40 40H460V140H40Z" fill="none" stroke="#1b2430" stroke-width="3"/>';
cs.forEach((k,j)=>{const x=110+350*(j+.5)/n,v=k=="R"?fmt(P.R,"Ω"):k=="L"?fmt(P.L,"mH"):fmt(P.C,"µF");h+=`<rect x="${x-34}" y="22" width="68" height="36" fill="#fff"/><path fill="none" stroke="#1b2430" stroke-width="3" d="${SY[k](x)}"/><text x="${x}" y="16" text-anchor="middle" font-size="15">${k} = ${v}</text><text x="${x}" y="76" text-anchor="middle" font-size="14">${k=="R"?"":k=="L"?"XL = "+fmt(M.XL)+" Ω":"XC = "+fmt(M.XC)+" Ω"}</text>`});
h+=`<circle cx="40" cy="90" r="24" fill="#fff" stroke="#1b2430" stroke-width="3"/><path d="M28 90q6-14 12 0t12 0" fill="none" stroke="#1b2430" stroke-width="2"/><text x="72" y="170" font-size="15">v: ${fmt(P.V)} V rms, ${fmt(P.f)} Hz</text><path d="M84 40l-9-5v10z" fill="#1b2430"/><text x="76" y="30" font-size="15">i</text>`;
h+=Array.from({length:20},(_,k)=>`<circle id="d${k}" r="4" fill="#d55e00" stroke="#fff"/>`).join("");$("ckt").innerHTML=h;DOTS=Array.from({length:20},(_,k)=>$("d"+k))}
function plot(id,ser,o={}){const c=$(id),dpr=devicePixelRatio||1,W=c.clientWidth,H=o.h||190;if(!W)return;if(c.width!==Math.round(W*dpr)||c.height!==H*dpr){c.width=Math.round(W*dpr);c.height=H*dpr;c.style.height=H+"px"}
const g=c.getContext("2d");g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,W,H);const Tw=nper*M.T,N=200,top=40,bot=H-18,L0=8;
const ys=ser.map(s=>Array.from({length:N+1},(_,k)=>s.f(Tw*k/N)));const mx=o.mx||Math.max(1e-12,...ys.flat().map(Math.abs));
const Y=v=>o.pos?bot-v/mx*(bot-top):(top+bot)/2-v/mx*((bot-top)/2);const X=t=>L0+t/Tw*(W-2*L0);
g.font="11px system-ui";g.strokeStyle="#aab5c3";g.lineWidth=1;g.beginPath();g.moveTo(L0,Y(0));g.lineTo(W-L0,Y(0));g.stroke();g.fillStyle="#333";
g.fillText((o.pos?"":"+")+fmt(mx)+" "+(o.u||""),L0,top-4);g.fillText("0 … "+fmt(Tw*1e3)+" ms",W-110,H-4);
let lx=L0,ly=11;ser.forEach((s,j)=>{const w=g.measureText(s.n).width+36;if(lx+w>W){lx=L0;ly+=14}g.strokeStyle=s.c;g.setLineDash(s.d);g.lineWidth=2;g.beginPath();g.moveTo(lx,ly-3);g.lineTo(lx+22,ly-3);g.stroke();g.fillStyle="#222";g.fillText(s.n,lx+26,ly);lx+=w;
g.beginPath();ys[j].forEach((v,k)=>k?g.lineTo(X(Tw*k/N),Y(v)):g.moveTo(X(0),Y(v)));g.stroke()});
g.setLineDash([]);g.strokeStyle="#000";g.lineWidth=1;const tx=X(phase*Tw);g.beginPath();g.moveTo(tx,top);g.lineTo(tx,bot);g.stroke()}
function tri(){const c=$("c4"),dpr=devicePixelRatio||1,W=c.clientWidth,H=220;if(!W)return;c.width=Math.round(W*dpr);c.height=H*dpr;c.style.height=H+"px";const g=c.getContext("2d");g.setTransform(dpr,0,0,dpr,0,0);g.font="12px system-ui";
const k=Math.min(W-200,H-80)/Math.max(M.S,1e-9),x0=40,y0=M.Q>=0?H-30:30,px=x0+M.Pw*k,qy=y0-M.Q*k;g.lineWidth=3;
g.strokeStyle="#009e73";g.beginPath();g.moveTo(x0,y0);g.lineTo(px,y0);g.stroke();g.strokeStyle="#cc79a7";g.setLineDash([6,4]);g.beginPath();g.moveTo(px,y0);g.lineTo(px,qy);g.stroke();g.setLineDash([]);g.strokeStyle="#0072b2";g.beginPath();g.moveTo(x0,y0);g.lineTo(px,qy);g.stroke();
g.fillStyle="#222";const bx=Math.max(x0+10,W-150);["P = "+fmt(M.Pw,"W"),"Q = "+fmt(M.Q,"var"),"S = "+fmt(M.S,"VA"),"θ = "+fmt(M.th*180/PI)+"°","PF = "+fmt(M.PF)].forEach((t,j)=>g.fillText(t,bx,H/2-30+j*18))}
function results(){const m=M,d=180/PI,r=[["ω","2πf",`2π·${fmt(P.f)}`,fmt(m.w,"rad/s")],["Vp","√2·Vrms",`1,4142·${fmt(P.V)}`,fmt(m.Vp,"V")],["XL","ωL",`${fmt(m.w)}·${fmt(m.L)}`,fmt(m.XL,"Ω")],["XC","1/(ωC)",`1/(${fmt(m.w)}·${fmt(m.Cc)})`,fmt(m.XC,"Ω")],
["Z","R+j(XL−XC)",`${fmt(m.Rr)}+j(${fmt(m.XL)}−${fmt(m.XC)})`,`${fmt(m.Rr)} ${m.X<0?"−":"+"} j${fmt(Math.abs(m.X))} Ω`],["|Z|","√(R²+(XL−XC)²)",`√(${fmt(m.Rr)}²+${fmt(m.X)}²)`,fmt(m.Z,"Ω")],["θ","atan2(XL−XC,R)",`atan2(${fmt(m.X)},${fmt(m.Rr)})`,fmt(m.th*d,"°")],
["Irms","Vrms/|Z|",`${fmt(P.V)}/${fmt(m.Z)}`,fmt(m.I,"A")],["Ip","√2·Irms",`1,4142·${fmt(m.I)}`,fmt(m.Ip,"A")],["PF","cosθ",`cos(${fmt(m.th*d)}°)`,fmt(m.PF)],["P","Vrms·Irms·cosθ",`${fmt(P.V)}·${fmt(m.I)}·${fmt(m.PF)}`,fmt(m.Pw,"W")],
["Q","Vrms·Irms·sinθ",`${fmt(P.V)}·${fmt(m.I)}·sin(${fmt(m.th*d)}°)`,fmt(m.Q,"var")+(m.Q>1e-9?" (induktif)":m.Q<-1e-9?" (kapasitif)":"")],["S","Vrms·Irms",`${fmt(P.V)}·${fmt(m.I)}`,fmt(m.S,"VA")],["√(P²+Q²)","S²=P²+Q²",`√(${fmt(m.Pw)}²+${fmt(m.Q)}²)`,fmt(Math.hypot(m.Pw,m.Q),"VA")],
["WL maks","½L·Ip²",`½·${fmt(m.L)}·${fmt(m.Ip)}²`,m.hL?fmt(.5*m.L*m.Ip**2,"J"):"—"],["WC maks","½C·(Ip·XC)²",`½·${fmt(m.Cc)}·(${fmt(m.Ip)}·${fmt(m.XC)})²`,m.hC?fmt(.5*m.Cc*(m.Ip*m.XC)**2,"J"):"—"],["f0","1/(2π√LC)",`1/(2π√(${fmt(m.L)}·${fmt(m.Cc)}))`,mode=="RLC"?fmt(m.f0,"Hz"):"— (hanya RLC)"]];
$("res").innerHTML="<tr><th>Besaran</th><th>Hasil</th><th class='steps'>Rumus</th><th class='steps'>Substitusi</th></tr>"+r.map(a=>`<tr><td>${a[0]}</td><td><b>${a[3]}</b></td><td class="steps">${a[1]}</td><td class="steps">${a[2]}</td></tr>`).join("");
const tip=Math.abs(m.th)<.01?"Tegangan dan arus sefase (resistif): seluruh daya semu menjadi daya aktif.":m.X>0?"Beban induktif: arus tertinggal dari tegangan, Q positif.":"Beban kapasitif: arus mendahului tegangan, Q negatif.";
$("interp").textContent=tip+(mode=="RLC"?` Resonansi ideal pada f0 = ${fmt(m.f0)} Hz (f sekarang ${fmt(P.f)} Hz).`:"")}
function draw(){const m=M,tc=phase*nper*m.T,g=sig(tc);
plot("c1",[{n:`v (puncak ${fmt(m.Vp)} V)`,c:"#0072b2",d:[],f:t=>sig(t).v/m.Vp},{n:`i (puncak ${fmt(m.Ip)} A)`,c:"#d55e00",d:[8,4],f:t=>sig(t).i/m.Ip}],{mx:1,u:"(±1 = puncak)"});
plot("c2",[{n:"sumber",c:"#000",d:[],f:t=>sig(t).pS},{n:"R",c:"#009e73",d:[8,4],f:t=>sig(t).pR},{n:"L",c:"#cc79a7",d:[2,3],f:t=>sig(t).pL},{n:"C",c:"#e69f00",d:[10,3,2,3],f:t=>sig(t).pC},{n:"R+L+C",c:"#56b4e9",d:[4,4],f:t=>sig(t).pT}],{u:"W"});
plot("c3",[{n:"WL",c:"#cc79a7",d:[2,3],f:t=>sig(t).WL},{n:"WC",c:"#e69f00",d:[10,3,2,3],f:t=>sig(t).WC}],{pos:1,u:"J",h:150});
const iN=g.i/m.Ip;DOTS.forEach((d,k)=>{const p=pos(k*52+iN*14);d.setAttribute("cx",p[0]);d.setAttribute("cy",p[1])});
$("bal").textContent=`t = ${fmt(tc*1e3)} ms\npS = ${fmt(g.pS)} W\npR = ${fmt(g.pR)}  pL = ${fmt(g.pL)}  pC = ${fmt(g.pC)} W\npR+pL+pC = ${fmt(g.pT)} W\nResidual = ${(g.pS-g.pT).toExponential(2)} W`}
function update(){calc();ST=stats();build();results();$("avg").innerHTML=`Rata-rata 1 periode (400 sampel): sumber ${fmt(ST.pS,"W")}, R ${fmt(ST.pR,"W")} (analitik ${fmt(M.Pw,"W")}), L ${ST.pL.toExponential(1)} W, C ${ST.pC.toExponential(1)} W. Residual maks ${ST.res.toExponential(2)} W (galat numerik floating-point, bukan pelanggaran kekekalan energi).`;draw();tri()}
function load(p){mode=p.m;Object.assign(P,DEF,{R:P.R,L:P.L,C:P.C},Object.fromEntries(Object.entries(p).filter(([k])=>k in D)));if(p.k)P.f=Math.min(1000,Math.max(1,p.k*f0of(P.L,P.C)));sync();update()}
$("mode").onchange=e=>{$("preset").value="";mode=e.target.value;sync();update()};
$("preset").onchange=e=>{if(PRE[e.target.value])load(PRE[e.target.value])};
$("play").onclick=()=>{playing=!playing;$("play").textContent=playing?"Jeda":"Lanjutkan";$("status").textContent=playing?"Berjalan":"Dijeda"};
$("reset").onclick=()=>{P={...DEF};mode="RLC";phase=0;$("preset").value="";sync();update()};
$("help").onclick=()=>{const h=$("guide");h.hidden=!h.hidden;$("help").setAttribute("aria-expanded",!h.hidden)};
$("steps").onclick=()=>{const s=$("res").classList.toggle("show");$("steps").textContent=s?"Sembunyikan langkah perhitungan":"Tampilkan langkah perhitungan"};
$("spd").oninput=e=>{speed=+e.target.value;$("spdv").textContent=speed+"×"};
$("npr").oninput=e=>{nper=+e.target.value;$("nprv").textContent=nper;draw()};
addEventListener("resize",()=>{draw();tri()});
function frame(ts){if(document.hidden)last=ts;else if(playing&&ts-last>33){phase=(phase+(ts-last)/1000*.08*speed)%1;last=ts;draw()}else if(!playing)last=ts;requestAnimationFrame(frame)}
if(matchMedia("(prefers-reduced-motion: reduce)").matches)$("play").click();
sync();update();requestAnimationFrame(frame);
